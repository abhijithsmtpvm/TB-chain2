import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { createHash } from 'crypto-browserify';
import { CryptoFactory, createContext } from "sawtooth-sdk/signing";
import * as protobuf  from "sawtooth-sdk/protobuf";
import { TextEncoder, TextDecoder} from "text-encoding/lib/encoding";
import {Buffer} from 'buffer/';
import {Secp256k1PrivateKey} from 'sawtooth-sdk/signing/secp256k1';


@Injectable({
  providedIn: 'root'
})
export class SawtoothService {
  private signer: any;
  public publicKey: any;
  public address: any;
  public transactionHeaderBytes: any;
  private context: any;
 
  private destSigner: any;
  private destPublicKey: any;
  private destAddress: any;
  
  private FAMILY_NAME = 'VaccBlock';
  private FAMILY_VERSION = '1.0';
  private REST_API_BASE_URL = 'http://localhost:4200/api';
  

  constructor(public http: HttpClient) { 
    this.context = createContext('secp256k1');
    // Creating a random private key - In LIVE, we will be using our own private keys
    //const privateKey = this.context.newRandomPrivateKey();
    //this.signer = new CryptoFactory(this.context).newSigner(privateKey);
    //this.publicKey = this.signer.getPublicKey().asHex();
    // Creating address
    //this.address =  this.hash("VaccBlockSource").substr(0, 6) + this.hash(this.publicKey).substr(0, 64);
    //console.log("Storing at:==1 " + this.address);
  }


  

   public setDestSigner(keyData){
    var temp = new Secp256k1PrivateKey( new Buffer.from(keyData,0,32));
    //var temp = Secp256k1PrivateKey.fromHex(keyData); 
    this.destSigner =new  CryptoFactory(this.context).newSigner(temp);
    this.destPublicKey = this.destSigner.getPublicKey().asHex();
    this.address =  this.hash("VaccBlockSource").substr(0, 6) + this.hash(this.destPublicKey).substr(0, 64);
    console.log("<<<<<Storing at Dest:>>>> " + this.address);
   }
  public clearLogin(): boolean {
    console.log("Cleared the login credentials");
    this.signer = null;
    this.publicKey = null;
    this.address = null;
    return true;
  }
  public addPrivateKey(keyData)
  {
    var temp = new Secp256k1PrivateKey( new Buffer.from(keyData,0,32));
    //var temp = Secp256k1PrivateKey.fromHex(keyData); 
    this.signer =new  CryptoFactory(this.context).newSigner(temp);
    this.publicKey = this.signer.getPublicKey().asHex();
    //this.publicKey = this.getPublicKeyAsHex(this.signer);
    //console.log("<<<<<public Key1>>>> " + this.signer.getPublicKey().asHex());
    //console.log("<<<<<public Key2>>>> " + this.hash(this.signer.getPublicKey().asHex()));
    //console.log(this.hash(this.publicKey).slice(-64));
    //console.log("<<<<<Storing at:0>>>> " + this.hash(this.FAMILY_NAME.substring(0,6)));
    //console.log("<<<<<Storing at:1>>>> " + this.hash(this.publicKey.asHex()).substr(0,32));
    //var tempAddr = this.FAMILY_NAME.substring(0,6) + this.publicKey.asHex();
    //this.address = this.hash(tempAddr.substring(0,32));
    //this.address = this.FAMILY_NAME.substring(0,6)+this.hash(this.publicKey.asHex()).substr(0,32);
    this.address =  this.hash("VaccBlockSource").substr(0, 6) + this.hash(this.publicKey).substr(0, 64);
    console.log("<<<<<Storing at Src:>>>> " + this.address);
  }


  public fixAddress(type)
  {
    if (type =="test")
    {

    }
  }

  private hash(v) {
    return createHash('sha512').update(v).digest('hex');
  }

  public async sendData(action, values) {
    // Encode the payload
    const payload = this.getEncodedData(action, values);
    const sec = this.getEncodedData("eat",10);
    const sec1 = this.getEncodedData("bake",11);
    debugger;
    var transactionsList = this.getTransactionsList(payload,sec);
    var  transactionTemp = this.getTransactionsList(sec,sec);
    var tempthird = this.getTransactionsList(sec1,sec);
    var  transactionTemp = this.getTransactionsList(sec,sec);
    var  third = this.getTransactionsList(sec1,sec1);
    let temp =transactionsList.concat(transactionTemp).concat(tempthird);
    console.log("Array Length" + temp.length);
    const batchList = this.getBatchList(temp);
    //debug
   //debugger;  
    // Send the batch to REST API
    await this.sendToRestAPI(batchList)
      .then((resp) => {
        console.log("response here", resp);
      })
      .catch((error) => {
        console.log("error here", error);
      })
  }

  public async sendToRestAPI(batchListBytes): Promise<any> {
    if (batchListBytes == null) {
      return this.getState(this.address)
        .then((response) => {
          return response.json();
        })
        .then((responseJson) => {
          return this.getDecodedData(responseJson)
        })
        .catch((error) => {
          console.error(error);
        });
    }
    else {
      console.log("new code");
      return this.postBatchList(batchListBytes)
    }
  }

  // Get state of address from rest api
  private async getState(address): Promise<any> {
    const getStateURL = this.REST_API_BASE_URL + '/state/' + address;
    const fetchOptions = { method: 'GET' };
    return window.fetch(getStateURL, fetchOptions);
  }

  // Post batch list to rest api
  private postBatchList(batchListBytes): Promise<any> {
    debugger;
    const postBatchListURL = this.REST_API_BASE_URL + '/batches';
    const fetchOptions = {
      method: 'POST',
      body: batchListBytes,
      headers: {
        'Content-Type': 'application/octet-stream'
      }
    }
    return window.fetch(postBatchListURL, fetchOptions);
  }  


  private getEncodedData(action, values): any {
    const data = action + "," + values;
    return new TextEncoder('utf8').encode(data);
  }

  private getDecodedData(responseJSON): string {
    const dataBytes = responseJSON.data;
    const decodedData = new Buffer(dataBytes, 'base64').toString();
    return decodedData;
  }

  /*---Signing & Addressing-------------------------*/
  private setCurrentTransactor(pkInput): boolean {
    try {
      const context = createContext('secp256k1');
      const secp256k1pk = this.getSecp256k1pk(pkInput);

      this.signer = this.getSignerInstanceForPrivateKey(context, secp256k1pk);
      this.publicKey = this.getPublicKeyAsHex(this.signer);
      this.address = this.getAddressOfCurrentUser(this.FAMILY_NAME, this.publicKey);
    }
    catch (e) {
      console.log("Error in reading the key details", e);
      return false;
    }
    return true;
  }

  private getSecp256k1pk(pkInput: String): Secp256k1PrivateKey {
    let secp256k1pk;
    if(typeof(pkInput) == typeof(ArrayBuffer)) {
      secp256k1pk = new Secp256k1PrivateKey(Buffer.from(pkInput, 0, 32));
    } else if(typeof(pkInput) == typeof(String)) {
      secp256k1pk = new Secp256k1PrivateKey().fromHex(pkInput);
    }
    return secp256k1pk;
  }

  private getSignerInstanceForPrivateKey(context, secp256k1pk): any {
    return new CryptoFactory(context).newSigner(secp256k1pk);
  }

  private getPublicKeyAsHex(signer): any {
    return signer.getPublicKey().asHex();
  }

  private getAddressOfCurrentUser(familyName, publicKey): any {
    let nameSpace = this.hash(familyName).substr(0, 6);
    let publicKeySpace = this.hash(publicKey).substr(0, 64);
    return (nameSpace + publicKeySpace);
  }

  /*------------------------------------*/

  /*-------------Creating transactions & batches--------------------*/
  private getTransactionsList(payload,sec): any {
    // Create transaction header
    const transactionHeader = this.getTransactionHeaderBytes([this.address], [this.address], payload);
    // Create transaction
    debugger;
   let transaction = this.getTransaction(transactionHeader, payload);
   //let temp = this.getTransaction(transactionHeader, sec);
    // Transaction list
    let transactionsList = [transaction];
    //const test = transactionsList.concat(temp);
    return transactionsList;

    //return transactionsList
  }

  private getBatchList(transactionsList): any {
    // List of transaction signatures
    const transactionSignatureList = transactionsList.map((tx) => tx.headerSignature);

    // Create batch header
    const batchHeader = this.getBatchHeaderBytes(transactionSignatureList);
    // Create the batch
    const batch = this.getBatch(batchHeader, transactionsList);
    // Batch List
    const batchList = this.getBatchListBytes([batch]);
    debugger;
    return batchList;
  }

  private getTransactionHeaderBytes(inputAddressList, outputAddressList, payload): any {
    const transactionHeaderBytes = protobuf.TransactionHeader.encode({
      familyName: this.FAMILY_NAME,
      familyVersion: this.FAMILY_VERSION,
      inputs: inputAddressList,
      outputs: outputAddressList,
      signerPublicKey: this.publicKey,
      batcherPublicKey: this.publicKey,
      dependencies: [],
      payloadSha512: this.hash(payload),
      nonce: (Math.random() * 1000).toString()
    }).finish();

    return transactionHeaderBytes;
  }

  private getTransaction(transactionHeaderBytes, payloadBytes): any {
    const transaction = protobuf.Transaction.create({
      header: transactionHeaderBytes,
      headerSignature: this.signer.sign(transactionHeaderBytes),
      payload: payloadBytes
    });

    return transaction;
  }

  private getBatchHeaderBytes(transactionSignaturesList): any {
    const batchHeader = protobuf.BatchHeader.encode({
      signerPublicKey: this.publicKey,
      transactionIds: transactionSignaturesList
    }).finish();

    return batchHeader;
  }

  private getBatch(batchHeaderBytes, transactionsList): any {
    const batch = protobuf.Batch.create({
      header: batchHeaderBytes,
      headerSignature: this.signer.sign(batchHeaderBytes),
      transactions: transactionsList
    });

    return batch;
  }
    
  private getBatchListBytes(batchesList): any {
    const batchListBytes = protobuf.BatchList.encode({
      batches: batchesList
    }).finish();

    return batchLi