import { Component, OnInit } from '@angular/core';
import { SawtoothService } from '../sawtooth.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl:'./login.component.html',
  styles: [
    "../node_modules/angular2-busy/build/style/busy.css",
    "styles.css"
  ]
})
export class LoginComponent implements OnInit {
  constructor(private router : Router ,private Data : SawtoothService) { 
    console.log("login",this.Data);
  
    //this.Data.clearLogin();
  }
  public otp:number =0;
  public defaultOTP: any;
  public inputOTP: any;
  public errorMsg: any;
  public myfield_control: any;
  public myUserName:string='';
  public myPassword:string='';
 
  otpNo1: string;
  ngOnInit() {
    this.otp =0;
  } 
  generateOTP(event)
  {
    this.defaultOTP = Math.floor(Math.random() * 100000); 
    this.errorMsg = ""
    this.otp =1;
   }
  login(event) {
    //check the OTP
    if ( this.inputOTP !== this.defaultOTP || this.otp == 0)
    {
      this.errorMsg = "Invalid OTP, please try again"
    }
    else if (this.myUserName.length ===0 || ! this.myUserName.trim() || this.myPassword.length === 0 || !this.myPassword.trim()){
      this.errorMsg = "Error in User Name or Password"
      
    }else
    {
      this.router.navigate(['home']);
    }
    
  }
  signup(){
    this.router.navigate(['signup']);
  }
     
}
    
 
    
 



