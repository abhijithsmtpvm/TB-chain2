import { Component, OnInit } from '@angular/core';
import { SawtoothService } from '../sawtooth.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-enroll',
  template: `
  <div class="Enroll">
  <div class="form" >  
  
 
  <tr > <td>
  <label for="lblAadharNumber">Aadhar Number</label>
  </td> <td>
  <input [(ngModel)]="aadharNo" name="aadharNo" type="text" maxlength="60" style="width: 300px;" />
   </td>
   </tr>
   <tr> <td>
  <label for="lblName">Name</label>
  </td> <td>
  <input [(ngModel)]="givenName" name="givenName" type="text" maxlength="60" style="width: 300px;" />
   </td>
   </tr>
   <tr> <td>
   <label for="lblDOB">DOB</label>
   </td> <td>
   <input [(ngModel)]="dob" name="dob" type="text" maxlength="60" style="width: 300px;" />
    </td>
    </tr>
    <tr> <td>
    <label for="lblPhoneNumber">PhoneNumber</label>
    </td> <td>
    <input [(ngModel)]="phoneNo" name="phoneNo" type="text" maxlength="60" style="width: 300px;" />
     </td>
     </tr>
     <tr> <td>
     <label for="lblbCity">City</label>
     </td> <td>
     <input [(ngModel)]="city" name="city" type="text" maxlength="60" style="width: 300px;" />
      </td>
      </tr>
      <tr> <td>
      <label for="lblState">State</label>
      </td> <td>
      <input [(ngModel)]="state" name="state" type="text" maxlength="60" style="width: 300px;" />
       </td>
       </tr>
      
   <tr> <td>
  <label for="lblcontactNumber">Contact Number</label>
  </td> <td>
  <input [(ngModel)]="contactNumber" name="contactNumber" type="text" maxlength="60" style="width: 300px;" />
   </td>
   </tr>
   <td>
            <button (click)="generateOTP($event)">Generate OTP</button>
        </td>
        <td>
            <input [(ngModel)]="defaultOTP" name="defOTP" type="text" maxlength="60" style="width: 300px;" />
        </td>
        <tr>
            <td>
                <label for="lblOTP">OTP</label>
            </td>
            <td>
                <input [(ngModel)]="inputOTP" name="inOTP" type="number" maxlength="60" style="width: 300px;" />
            </td>
        </tr>
    <button (click)="login($event)">Add</button>
    <div>
    <tr>
    <label id="lblName">
        {{errorMsg}}
    </label>
</tr>
</div>
   
   </div>
 </div>
 
  `,
  styles: [
    "../node_modules/angular2-busy/build/style/busy.css",
    "styles.css"
  ]
})
export class EnrollComponent implements OnInit {
  constructor(private router : Router ,private Data : SawtoothService) { 
    console.log("login",this.Data);
  }
  public aadharNo:number = 0;
  public givenName:string = '';
  public dob:Date = new Date();
  public phoneNo:number = 0;
  public city:string = '';
  public state:string ='';
  public contactNumber:number =0 ;
  public defaultOTP:number = 0;
  public inputOTP:number =0;
  public errorMsg:string ='';
  public otp:number=0;
  ngOnInit() {
    console.log("haii******************");
  } 
  generateOTP(event)
  {
    this.defaultOTP = Math.floor(Math.random() * 100000); 
    this.errorMsg = ""
    this.otp =1;
   }

   login(event) {
    //check the OTP
    if ( this.inputOTP !== this.defaultOTP || this.otp == 0)
    {
      this.errorMsg = "Invalid OTP, please try again"
    }
    else if (this.aadharNo <=0 || ! this.givenName.trim() || this.givenName.length === 0 || this.phoneNo <= 0 ){
      this.errorMsg = "Error in User Aadhar or Name or Password"
      
    }
    else if (!this.city.trim() ||  this.city.length === 0 || ! this.state.trim() || this.state.length === 0 || this.contactNumber <= 0 ){
      this.errorMsg = "Error in city or state or contatact number"
      
    }else
    {
      this.router.navigate(['home']);
    }
    
  }

   
 }
    
 



