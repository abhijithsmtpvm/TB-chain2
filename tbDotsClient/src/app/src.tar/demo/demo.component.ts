import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-demo',
  template: `
    <p>
      demo works!
    </p>
  `,
  styles: []
})
export class DemoComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
