import { Component, OnInit } from '@angular/core';
import { SawtoothService } from '../sawtooth.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-administer',
  template: `
  <div class="administer">
  <div class="form" >  
  
 
  <tr> <td>
  <label for="lblAadharNumber">Aadhar Number</label>
  </td> <td>
  <input name="aadharNumber" type="text" maxlength="60" />
   </td>
   </tr>
   <tr> <td>
  <label for="lblvaccinationName">Vaccination Name</label>
  </td> <td>
<select [(ngModel)]="otpNo" >
<option *ngFor="let group of arrayGroup" value={{group}} >
    {{group}}
</option>
</select>


 <!-- <input name="vaccinationName" type="text" maxlength="60" />-->
   </td>
   </tr>
   <tr>
   <td>
   <label for="lblvaccinationAge">Vaccination Age</label>
   </td>
   <td>
   <input name="vaccinationAge" type="text" maxlength="60" />
    </td>
    </tr>
   <tr> <td>
   <label for="lblBarCode">Bar Code</label>
   </td> <td>
   <input name="barCode" type="text" maxlength="60" />
    </td>
    </tr>
    <td>
   <button (click)="generateOTP($event)">Generate OTP</button>
   </td><td>
   <label for="lblOTP">OTP</label>
   </td>
   <tr> <td>
   <label for="lblOTP">OTP</label>
   </td> <td>
   <input name="OTP" type="number" maxlength="60" style="width: 300px;" />
    </td>
    </tr>
    <button (click)="login($event)">Administer</button>
   
 

   
   </div>
 </div>
 
  `,
  styles: [
    "../node_modules/angular2-busy/build/style/busy.css",
    "styles.css"
  ]
})
export class AdministerComponent implements OnInit {
  constructor(private router: Router, private Data: SawtoothService) {
    console.log("login", this.Data);
  }
  public  otpNo:string;
  public xyz:string;
  public arrayGroup:string[];
  
 
  ngOnInit() {
    //this.xyz = "he,wsws,swew";
    ///this.arrayGroup = this.xyz.split(",");
    const temp = "12121,3232,787";
    this.arrayGroup = temp.split(",");
    console.log(this.arrayGroup);
    console.log("haii******************");
  }
  login(event)
  {
    console.log(this.otpNo);
  }

}





