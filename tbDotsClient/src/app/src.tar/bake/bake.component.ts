import { Component, OnInit } from '@angular/core';
import { RouterModule } from '@angular/router';
import { SawtoothService } from '../sawtooth.service';

@Component({
  selector: 'app-bake',
  template: `
  <div class="bake">
  <div class="form">
    <form class="bake" (submit)="bakeCookie($event)">
  <input id="bake_id" type="text" placeholder="No of cookies"/>
  
  
  <button id="submit" type="submit" >Bake</button>

  </form>
  </div>
</div>



  `,
  styles: [
    "../node_modules/angular2-busy/build/style/busy.css",
    "styles.css"
  ]
})
export class BakeComponent implements OnInit {

  constructor(private Data : SawtoothService,private router :RouterModule) { }

  ngOnInit() {
  }
    bakeCookie(event){
      debugger;
      event.preventDefault()
      const target = event.target
      const bakevalue = target.querySelector('#bake_id').value;
      this.Data.sendData("bake", bakevalue);
      console.log(bakevalue);
    }
    

}


