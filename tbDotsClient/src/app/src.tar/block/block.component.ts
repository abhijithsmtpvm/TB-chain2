import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-block',
  templateUrl: `block.component.html'
   `,
  styles: []
})
export class BlockComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
