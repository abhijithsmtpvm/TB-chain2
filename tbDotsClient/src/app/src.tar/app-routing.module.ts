import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Routes, RouterModule } from '@angular/router';
import { BakeComponent } from './bake/bake.component';
import { EatComponent } from './eat/eat.component';
import { CountComponent } from './count/count.component';
import { LoginComponent } from './login/login.component';
import { TransferComponent } from './transfer/transfer.component';
import { HomeComponent } from './home/home.component';
import { SignUpComponent } from './signup/signup.component';
import { EnrollComponent } from './enroll/enroll.component';
import { VaccinationComponent } from './vaccination/vaccination.component';
import { AdministerComponent } from './administer/administer.component';
import { LookupComponent } from './lookup/lookup.component';
import { DashboardComponent } from '../app/dashboard/dashboard.component';


const routes: Routes = [
  {
    path: '',
    component: DashboardComponent
  },
  {
    path: 'login',
    component: LoginComponent
  },
  {
    path: 'signup',
    component: SignUpComponent
  },
  {
    path: 'home',
    component: HomeComponent,
    children: [
      {
        path: 'enroll',
        component: EnrollComponent
      },
      {
        path: 'vaccination',
        component: VaccinationComponent
      },
      {
        path: 'administer',
        component: AdministerComponent
      },
      {
        path: 'lookup',
        component: LookupComponent
      },

    ]
  },

]
@NgModule({
  imports: [RouterModule.forRoot(routes),
    CommonModule
  ],
  exports: [RouterModule],
  // CommonModule

  declarations: []
})
export class AppRoutingModule { }
