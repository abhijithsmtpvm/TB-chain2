import { Component, OnInit } from '@angular/core';
import { SawtoothService } from '../sawtooth.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-lookup',
  template: `
  <div class="lookup">
  <div class="form" >  
  
 
  <tr> <td>
  <label for="lblAadharNumber">Aadhar Number</label>
  </td> <td>
  <input name="aadharNumber" type="text" maxlength="60" style="width: 300px;" />
   </td>
   </tr>
  



  <td>
   <button (click)="generateOTP($event)">Generate OTP</button>
   </td><td>
   <label for="lblOTP">OTP</label>
   </td>
   <tr> <td>
   <label for="lblOTP">OTP</label>
   </td> <td>
   <input name="OTP" type="number" maxlength="60" style="width: 300px;" />
    </td>
    </tr>
    <button (click)="login($event)">Login</button>


  
   
   
 

   
   </div>
 </div>
 
  `,
  styles: [
    "../node_modules/angular2-busy/build/style/busy.css",
    "styles.css"
  ]
})
export class LookupComponent implements OnInit {
  constructor(private router : Router ,private Data : SawtoothService) { 
    console.log("login",this.Data);
  }

  ngOnInit() {
    console.log("haii******************");
  } 
  
 }
    
 



